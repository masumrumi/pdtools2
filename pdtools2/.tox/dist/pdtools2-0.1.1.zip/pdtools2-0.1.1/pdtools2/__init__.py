from pdtools2 import reduce_memory
from pdtools2.reduce_memory.mem_reduce import *
